<?php include_once('include/db_connection/user_session_include.php'); ?>
<html>
<head>
<style><?php include_once('include/css/style_sheet.css'); ?></style>
<script><?php include_once('include/js/java_script.js');?></script>
</head>
<body>
<?php include_once('include/db_connection/db_connection.php'); ?>
<?php include_once('include/php/menu.php'); ?>
<h1 class="div-class"><br><br>Welcome to <br>Election Human Resourse Managemet System (EHRMS)<br>Srikakulam District.<br></div>
<h2 class="div-class">&nbsp; &nbsp;</h2> </h1>
<h2 class="div-class"></h2>
<div class="divTable">
<div class="divTableBody">
<div class="divTableRow">
<div class="divTableCell">&nbsp &nbsp;</div>
<div class="divTableCell"></div>
<div class="divTableCell">&nbsp;</div>
</div>
</div>
</div>
<br/>
<?php include_once('include/php/footer_menu.php'); ?>
</body>
</html>