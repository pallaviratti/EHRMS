<?php include_once('include/db_connection/user_session_include.php'); ?>
<html>
<head>
<style><?php include_once('include/css/style_sheet.css'); ?></style>
<script><?php include_once('include/js/java_script.js');?></script>
</head>
<body>
<?php include_once('include/db_connection/db_connection.php'); ?>
<?php include_once('include/php/menu.php'); ?>
<h1 class="div-class">Contact Us</h1>
<h2 class="div-class">If you need any more information, please contact below team members:</h2>
<div class="divTable">
<div class="divTableBody">
<div class="divTableRow">
<div class="divTableCell"><h3>&nbsp;</h3></div>
<div class="divTableCell"><h3>1. Ms. Harika<br><br>2. Ms. Neha<br><br>3. Ms. Pallavi<br><br>4. Mr. Raj Kumar or<br><br> 5. Ms. Yogeswari</h3></div>
<div class="divTableCell"><h3>&nbsp;</h3></div>
</div>
</div>
</div>
<br/>
<?php include_once('include/php/footer_menu.php'); ?>
</body>
</html>