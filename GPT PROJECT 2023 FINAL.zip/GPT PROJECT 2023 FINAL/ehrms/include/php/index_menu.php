<?php
echo "<header>";

echo "<nav id='cssmenu'>";
echo "<div class='logo'><a href='home.php'><image src='include/img/ehrms_logo.png' width='20%'/></a></div>";


//echo "<nav id='cssmenu'>";
//echo "<div class='logo' style='padding:12px 0 18px 20px;'><image src='include/img/ehrms_logo.png' /></div>";
echo "<div id='head-mobile'></div>";
echo "<div align='center' style='color:#FFFFFF; padding:20px 0 0 0;font:20px verdana;'>Election Human Resourse Managemet System (EHRMS), Srikakulam District</div>";
echo "<ul>"; 
echo "</ul>";
echo "</nav>";
echo "</header>";
?>