<?php
echo "<nav id='cssmenu' style='position:relative; z-index:-100;'>";
//echo "<div id='head-mobile'></div>";
//echo "<div class='button'></div>";
echo "<div>";
echo "<p align='center' style='color:#FFFFFF; font:13px verdana;'>Content Owned by District Administration<sup>©</sup> Srikakulam District, Andhra Pradesh,<br>This demo project developed by Interns of <a href='#' style='color:#1cb0fa;'>Govt. Polytechnic College, Srikakulam</a> and hosted by <i><a href='#' style='color:#1cb0fa;'>National Informatics Centre,</a></i><br><a>Ministry of Electronics & Information Technology,</a> Government of India<br><br></p>";
echo "</div>";
echo "</nav>";
?>