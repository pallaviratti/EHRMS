<?php include_once('include/db_connection/user_session_include.php'); ?>
<html>
<head>
<style><?php include_once('include/css/style_sheet.css'); ?></style>
<script><?php include_once('include/js/java_script.js');?></script>
</head>
<body>
<?php include_once('include/db_connection/db_connection.php'); ?>
<?php include_once('include/php/menu.php'); ?>
<h1 class="div-class">About Us</h1>
<h3 class="div-class-body-text">We are interns of Govt. Polytechnic College, Srikakulam. This is our project on Election Human Resourse Managemet System (EHRMS) of Srikakulam District. This project aims to manage all human resource related to Elections in the district.</h3>
<h2 class="div-class">Team Members (in Alphabetical Order):</h2>
<div class="divTable">
<div class="divTableBody">
<div class="divTableRow">
<div class="divTableCell"><h3>&nbsp; &nbsp;</h3></div>
<div class="divTableCell"><h3>1. Ms. Harika<br><br>2. Ms. Neha<br><br>3. Ms. Pallavi<br><br>4. Mr. Raj Kumar &<br><br> 5. Ms. Yogeswari</h3></div>
<div class="divTableCell">&nbsp;</div>
</div>
</div>
</div>
<br/>
<?php include_once('include/php/footer_menu.php'); ?>
</body>
</html>